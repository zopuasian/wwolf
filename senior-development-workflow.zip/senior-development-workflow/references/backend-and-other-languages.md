# Backend, APIs, Data, and Other Languages

Use this reference for service code, data models, integration boundaries, databases, scripts, and non-TypeScript languages.

## Backend Design

- Keep request validation, authorization, domain logic, persistence, and presentation concerns distinct according to local architecture.
- Make idempotency explicit for retries, webhooks, billing, jobs, and mutation endpoints.
- Handle timeouts, cancellation, retries, backoff, and partial failure at integration boundaries.
- Treat logs, metrics, traces, and error reporting as part of production behavior.
- Avoid leaking internal errors, secrets, tokens, stack traces, or sensitive identifiers to clients.

## APIs and Contracts

- Preserve backwards compatibility unless the user explicitly asks for a breaking change.
- Version or migrate contracts when clients may lag.
- Validate input at the boundary and serialize output intentionally.
- Make pagination, sorting, filtering, and consistency semantics explicit.
- For authz, check object-level access, not just route-level authentication.

## Data and SQL

- Use parameterized queries or ORM-safe APIs.
- Consider transaction boundaries, isolation, uniqueness, and race conditions.
- Make migrations reversible when the project expects it.
- Backfill and deploy in phases for large or risky schema changes.
- Index for actual query patterns and verify cardinality assumptions.
- Avoid N+1 reads across hot paths.

## Python

- Prefer clear modules, typed function signatures where the project uses typing, and explicit dependency boundaries.
- Use context managers for files, network clients, database sessions, and locks.
- Keep data validation close to IO boundaries with dataclasses, Pydantic, attrs, or local conventions.
- Avoid mutable defaults and broad exception swallowing.

## Go

- Keep errors contextual and check them immediately.
- Pass `context.Context` through request-scoped operations.
- Prefer small interfaces at consumers, not broad provider-side interfaces.
- Avoid goroutine leaks; define cancellation and channel ownership.
- Use table-driven tests for branchy logic.

## Java, Kotlin, and C#

- Preserve nullability contracts and framework lifecycle assumptions.
- Keep DTOs, domain entities, persistence models, and API models distinct when the repo already separates them.
- Avoid overusing inheritance for simple composition.
- Make exceptions meaningful and avoid catching too broadly.

## Rust, C, and Systems Code

- Respect ownership, lifetime, and thread-safety boundaries.
- Keep unsafe blocks tiny and justified.
- Prefer clear error types and avoid panics in library or service paths.
- Verify resource cleanup, memory bounds, and concurrency assumptions.

## Shell and Automation

- Quote variables, handle spaces, set strict modes only when compatible with the script's expected behavior.
- Prefer idempotent commands and clear failure messages.
- Avoid destructive operations unless explicitly requested and reviewed.
