# Testing, Review, Debugging, Refactoring, and Release Safety

Use this reference when choosing verification strategy, reviewing diffs, debugging bugs, or refactoring production code.

## Testing Strategy

- Match test scope to risk: unit tests for pure logic, integration tests for boundaries, component tests for UI behavior, e2e tests for critical flows.
- Add regression coverage for bug fixes when practical.
- Test behavior, not implementation details.
- Keep fixtures small and meaningful.
- Include negative, empty, permission, loading, and error cases when they are part of the risk.
- Avoid snapshot churn unless snapshots are intentionally reviewed.

## Verification Hierarchy

Prefer the strongest practical signal:

1. Reproduce the bug or target behavior.
2. Run focused tests around changed code.
3. Run typecheck/lint/build when the change touches shared surfaces.
4. Run browser/manual checks for meaningful UI changes.
5. Explain any verification that could not be run.

## Code Review Checklist

- Correctness: Does it solve the actual problem under realistic data and timing?
- Contracts: Are APIs, types, schemas, events, env vars, and storage keys compatible?
- State: Are loading, empty, error, retry, optimistic, disabled, and stale states handled?
- Security: Are authz, injection, secrets, XSS, CSRF, SSRF, and data exposure considered?
- Performance: Are hot paths, N+1 queries, expensive renders, payload size, caching, and memory considered?
- Accessibility: Are semantics, keyboard use, focus, labels, and contrast preserved?
- Maintainability: Are names, boundaries, tests, and dependencies easy to reason about?

## Debugging Workflow

- State the observed failure and expected behavior.
- Identify the boundary where reality diverges: input, state transition, network, persistence, render, or build.
- Use logs, tests, breakpoints, traces, or targeted instrumentation to prove the cause.
- Patch the cause, not the nearest symptom.
- Remove temporary debugging artifacts before finalizing.

## Refactoring Rules

- Refactor with a behavioral safety net when risk is nontrivial.
- Keep mechanical changes separate from behavior changes when possible.
- Preserve public contracts and update all call sites intentionally.
- Stop when the code is simpler enough to justify the diff.

## Release Safety

- Consider feature flags, phased rollout, migrations, compatibility windows, and rollback plans for risky changes.
- Check generated files, lockfiles, environment assumptions, and build artifacts before final response.
- Report residual risk clearly without dramatizing it.
