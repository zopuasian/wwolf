# TypeScript, JavaScript, React, and Node

Use this reference for TypeScript-heavy application work, frontend state, Node services, package tooling, and JavaScript runtime behavior.

## TypeScript Standards

- Prefer precise domain types over broad `any`, `object`, or stringly typed bags.
- Use `unknown` at unsafe boundaries, then narrow with validators, guards, schemas, or explicit checks.
- Keep public types stable and intentional. Search all callers before changing exported types.
- Model impossible states as impossible with discriminated unions, branded IDs, literal unions, and exhaustive checks.
- Avoid type assertions unless they sit at a proven boundary and are documented by surrounding code.
- Prefer inferred local types and explicit exported function/component/API types.
- Use strict null handling. Decide whether absence is `undefined`, `null`, empty collection, or omitted field, then stay consistent.
- Avoid over-generic helpers. Add generics only when they preserve information the caller actually uses.

## JavaScript Runtime

- Remember that TypeScript types disappear at runtime. Validate network, file, URL, env, storage, and user-input data.
- Handle async cancellation, ordering, duplicate requests, retries, and stale responses in UI and service code.
- Avoid hidden mutation in shared objects. Use immutable updates where state identity affects rendering or caching.
- Treat date, timezone, locale, currency, and number formatting as product behavior.

## React and Frontend State

- Keep derived state derived. Store source-of-truth state only when needed.
- Stabilize callbacks and memoization only when they prevent real churn or satisfy dependency contracts.
- Put side effects in effects, event handlers, loaders, actions, or service boundaries according to the framework's convention.
- Make loading, empty, partial, error, optimistic, and disabled states explicit.
- Prefer accessible native controls before custom widgets.
- For forms, define validation ownership clearly: client convenience, server authority.
- Avoid prop drilling by following existing local patterns; do not introduce global state for a narrow feature.

## Node, APIs, and Tooling

- Validate env vars at startup for services and build-time code.
- Keep API errors typed enough for callers and safe enough for users.
- Separate transport concerns from domain logic when the codebase already has service layers.
- Respect package manager lockfiles and existing script names.
- Before adding dependencies, check whether the platform, framework, or repo already provides the capability.

## Common Pitfalls

- Passing compile by weakening types.
- Fixing a symptom in a component while the data contract remains broken.
- Adding memoization that hides stale closure bugs.
- Treating server/client boundaries as implementation details in SSR or app-router frameworks.
- Updating UI state after an unmounted component or after a newer request has superseded an older one.
