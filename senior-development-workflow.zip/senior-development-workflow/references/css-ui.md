# CSS, UI, Accessibility, and Visual QA

Use this reference for frontend appearance, layout, responsiveness, component polish, accessibility, and browser verification.

## CSS Architecture

- Follow the repo's styling system first: CSS modules, Tailwind, vanilla CSS, styled components, design tokens, or component library conventions.
- Keep layout concerns separate from component semantics when practical.
- Prefer tokens and semantic variables for colors, spacing, radii, typography, shadows, and breakpoints.
- Avoid one-off magic numbers unless they solve a real local alignment issue.
- Use stable layout primitives: grid/flex constraints, min/max sizes, aspect ratios, and overflow rules.
- Prevent layout shift from hover states, dynamic labels, loading indicators, validation messages, and async content.

## Responsive Layout

- Design for content first, viewport second. Long labels, translated strings, user data, and empty states must fit.
- Use container-aware constraints where possible.
- Do not scale font size directly with viewport width.
- Keep touch targets usable on mobile.
- Test narrow, common desktop, and wide desktop widths for important UI.

## Visual Quality

- Match the existing product tone. Operational tools should be dense, quiet, and scannable; editorial or game experiences can be more expressive.
- Use cards only for actual repeated items, modals, or framed tools. Avoid cards inside cards.
- Avoid decorative gradients, blobs, and ornamental surfaces unless the product style already uses them.
- Use icons for common actions when available, with labels or tooltips where meaning is not obvious.
- Make focus, hover, active, disabled, selected, loading, and error states visible and consistent.

## Accessibility

- Preserve semantic HTML: buttons for actions, links for navigation, labels for inputs, headings in order.
- Ensure keyboard reachability and visible focus.
- Use ARIA to complete semantics, not replace native behavior.
- Keep color contrast sufficient in normal, hover, disabled, and selected states.
- Do not rely on color alone for status or validation.
- Respect reduced-motion preferences for nonessential animation.

## Browser Verification

- For significant UI changes, run or open the app and inspect actual rendered output.
- Check for overlap, clipping, horizontal scroll, unreadable text, broken assets, invisible focus, and console errors.
- For canvas/WebGL/3D, verify nonblank rendering and interaction at multiple viewport sizes.

## Common Pitfalls

- Fixing desktop while creating mobile overflow.
- Adding absolute positioning where normal layout would be more robust.
- Using `z-index` to hide structural layering issues.
- Styling disabled controls so they look broken or inaccessible.
- Introducing a visually polished component that ignores existing density and navigation patterns.
